class Result < ApplicationRecord
    
end
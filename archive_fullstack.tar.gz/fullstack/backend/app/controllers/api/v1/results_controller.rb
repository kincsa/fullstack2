class Api::V1::ResultsController < ApplicationController
  def index
    results = Result.all()
    render json: results, status: 200
  end

  def new
    result = Result.new
  end

  def create
    result = Result.new(
      name: result_params[:name],
      points: result_params[:points]
    )
    if result.save
      render json: result, status: 200
    else
      render json: { error: "creating error..." }
    end
  end

  def show
    result = Result.find(params[:id])
    if result
      render json: result, status: 200
    else
      render json: { error: "Result not found!" }
    end
  end

  def update
    result = Result.find(params[:id])
    if result
      result.update(name: params[:name], points: params[:points])
      render json: "Result updated successfully"
    else
      render json: { error: "Result not found" }
    end
  end

  def destroy
    result = Result.find(params[:id])
    if result
      result.destroy
      render json: "Result deleted successfully"
    end
  end

  private

  def result_params
    params.require(:result).permit(:name, :points)
  end
end

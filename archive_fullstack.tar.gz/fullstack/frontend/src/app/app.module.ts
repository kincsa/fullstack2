import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ListresultsComponent } from './listresults/listresults.component';
import { CreateresultComponent } from './createresult/createresult.component';
import { EditresultComponent } from './editresult/editresult.component';
import { ResultService } from './services/result.service';

@NgModule({
  declarations: [
    AppComponent,
    ListresultsComponent,
    CreateresultComponent,
    EditresultComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ResultService],
  bootstrap: [AppComponent]
})

export class AppModule { }

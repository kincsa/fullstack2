import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListresultsComponent } from './listresults.component';

describe('ListresultsComponent', () => {
  let component: ListresultsComponent;
  let fixture: ComponentFixture<ListresultsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListresultsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ListresultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResultService } from '../services/result.service';
import { subscribe } from 'diagnostics_channel';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-listresults',
  standalone: true,
  imports: [CommonModule],
  providers: [HttpClient, ResultService],
  templateUrl: './listresults.component.html',
  styleUrl: './listresults.component.scss'
})
export class ListresultsComponent {

  results:any;

  constructor(private resultService: ResultService){

  }

  ngOnInit(){
    this.ResultList();
  }

  ResultList(){
    this.resultService.listResult().subscribe(
        result => {
        this.results = result;
        console.log(this.results);
        }
      ) 
    }
  }

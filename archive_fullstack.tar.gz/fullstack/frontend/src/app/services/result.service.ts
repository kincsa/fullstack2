import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ResultService {

  url:string = "http://127.0.0.1:3000";
  constructor(private http: HttpClient) { }

  listResult(){
     return this.http.get(this.url+ '/api/v1/results');
  }

  httpOptions = {
    headers : new HttpHeaders(
      {
        "Content-type" : "application/json"
      }
    )
  };

  addResult(data : any){
    return this.http.post(this.url+ '/api/v1/results', data, this.httpOptions);
  }

  findResult(){

  }

  updateResult(){

  }

  deleteResult(){

  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateresultComponent } from './createresult.component';

describe('CreateresultComponent', () => {
  let component: CreateresultComponent;
  let fixture: ComponentFixture<CreateresultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreateresultComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CreateresultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

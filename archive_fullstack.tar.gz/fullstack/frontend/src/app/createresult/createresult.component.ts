import { subscribe } from 'diagnostics_channel';
import { ResultService } from './../services/result.service';
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-createresult',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './createresult.component.html',
  styleUrl: './createresult.component.scss'
})
export class CreateresultComponent {

  result : any;

  resultForm = new FormGroup({
    name: new FormControl(''),
    points: new FormControl('')
  });

  constructor(private resultService : ResultService){
    
  }

  onSubmit(){
    this.resultService.addResult(this.resultForm.value).subscribe(
      result => {
        this.result = result;
      }
    );
  }

}

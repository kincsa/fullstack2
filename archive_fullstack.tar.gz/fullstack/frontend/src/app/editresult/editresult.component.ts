import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-editresult',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './editresult.component.html',
  styleUrl: './editresult.component.scss'
})
export class EditresultComponent {

}
